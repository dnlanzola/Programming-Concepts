/***********************\
*      Assignment 1     *
* Daniel Anzola Delgado *
\***********************/

/*
   INSTRUCTIONS:
   Write a simple Java Program that outputs your name to the screen, following the wordHello.

*/


public class HelloName 
{
   public static void main(String[] args) 
   {
      System.out.println("Daniel Hello");    //Prints "Daniel Hello"
   }
    
}